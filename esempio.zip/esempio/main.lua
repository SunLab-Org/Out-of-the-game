
function love.load()

end

function love.update(dt)

end

function love.draw()
    print('test')
    print('test2')
    love.graphics.print("CIAO MONDO! ", 50, 50 ) 
    love.graphics.print("CIAO MONDO22! ", 50, 80 ) 

end

