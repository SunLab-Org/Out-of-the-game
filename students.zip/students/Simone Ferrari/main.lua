push = require 'push'
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
VIRTUAL_WIDTH = 800
VIRTUAL_HEIGHT = 800
local x = 50
local y = 50
local Immagine = love.graphics.newImage("Razzo.png")
local Image = love.graphics.newImage("Ostacolo.png")
local Im = love.graphics.newImage("Buco.png")
local spostamentoy = 0
local spostamentox = 2
local tempo = 0.4
local timer = 1.5
local vel = 100
local w = 45
local h = 88

local Buco = {
    x = 700,
    y = 200,
    w = 32,
    h =  32
}

local Ostacolo = {}
local punti = 0

love.graphics.setDefaultFilter("nearest", "nearest")

function isColliding(f)
    return spostamentox < f.x + f.w and
            spostamentox + w > f.x and
           spostamentoy < f.y + f.h and
           spostamentoy + h > f.y 
end


function love.load()
    love.graphics.setDefaultFilter('nearest', 'nearest')
    -- set the title of our application window
    love.window.setTitle('Razzo nello spazio')

    -- "seed" the RNG so that calls to random are always random
    -- use the current time, since that will vary on startup every time
    math.randomseed(os.time())


    -- initialize window with virtual resolution
    push:setupScreen(VIRTUAL_WIDTH, VIRTUAL_HEIGHT, WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = true,
        resizable = true,
        vsync = true
    })

    music = love.audio.newSource("Suono buco.wav", "static")
    suono = love.audio.newSource("Suono fiamma.wav", "static")

end

function love.resize(w, h)
    push:resize(w, h)
end

function love.update(dt)
    timer = timer - dt


    if love.keyboard.isDown("s") then
        spostamentoy = spostamentoy + 3
        spostamentoy = math.min(VIRTUAL_HEIGHT-88, spostamentoy)
    end

    if love.keyboard.isDown("w") then
        spostamentoy = spostamentoy - 3
        spostamentoy = math.max(0, spostamentoy)
    end

    if love.keyboard.isDown("a") then
        spostamentox = spostamentox - 3
        spostamentox = math.max(0, spostamentox)
    end

    if love.keyboard.isDown("d") then
        spostamentox = spostamentox + 3
        spostamentox = math.min(VIRTUAL_WIDTH-45, spostamentox)
    end 

    if #Ostacolo > 0 then 
        for _,o in ipairs(Ostacolo) do 
            o.y = o.y + vel * dt
        end 

        for _,o in ipairs(Ostacolo) do 
            if isColliding(o) then 
                suono:play()
                love.event.quit()
            end 
        end

        if Ostacolo[1].y > VIRTUAL_HEIGHT then 
            table.remove(Ostacolo, 1)
        end
    end

    if timer < 0 then 
        timer = tempo 
        local random = math.random(0, 800)
        print(random)
        table.insert(Ostacolo, {
            x = random,
            y = 0,
            w = 32,
            h = 48,
        })

        tempo = tempo - dt/4
        vel = vel + 10
    end

    if isColliding(Buco) then 
        music:play()
        Buco.x = math.random(0, 750)
        Buco.y = math.random(0, 750)
         spostamentoy = 0
         spostamentox = 2
        Ostacolo = {}
        punti = punti + 1
    end

end

function love.draw()
    push:apply('start')

    love.graphics.clear(0.1,0.2,0.3)
    if #Ostacolo > 0 then 
        for _,o in ipairs(Ostacolo) do 
            print(Ostacolo)
            love.graphics.draw(Image, o.x, o.y, 0, 2, 2)
            --love.graphics.rectangle("line", o.x, o.y, o.w, o.h)
        end
    end

    love.graphics.draw(Immagine, spostamentox, spostamentoy, 0, 2, 2)
    --love.graphics.rectangle("line", spostamentox, spostamentoy, w, h)
    love.graphics.draw(Im, Buco.x, Buco.y, 0, 3, 3)
    love.graphics.print("Punteggio: " .. punti, 700, 0)

    push:apply('end')
end

function love.keypressed(key)
    if key == "escape" then
        love.event.quit()
    end

end

