

function love.conf(t)    
    t.console = true 
end