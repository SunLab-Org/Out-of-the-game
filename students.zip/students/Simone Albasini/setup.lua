palline = {}
love.graphics.setDefaultFilter("nearest", "nearest")

-- PARAMETRI TAVOLO
local tableWidth  = 1058
local tableHeight = 424

-- TRIANGOLO
local startX = 400       -- punta a destra del tavolo
local startY = tableHeight / 2        -- centro verticale

local d = 30                          -- distanza orizzontale (diametro pallina)
local h = d * math.sin(math.rad(60))  -- distanza verticale tra le righe (~26)

local positions = {}

-- Aggiunge una riga del triangolo
local function addRow(count, row)
    local x = startX - (row - 1) * d      -- ogni riga va più a sinistra
    local y = 0
    y = startY

    for i = 1, count do
        table.insert(positions, {
            x = x,
            -- centriamo verticalmente la riga
            y = y + (i - (count + 1) / 2) * d
        })
    end
end

-- Costruzione triangolo (1 + 2 + 3 + 4 + 4 = 14 palline)
addRow(1, 1)
addRow(2, 2)
addRow(3, 3)
addRow(4, 4)
addRow(5, 5)

-- CREA LE 14 PALLINE
for i = 1, 15 do
    table.insert(palline, {
        x = positions[i].x,
        y = positions[i].y,
        r = 15,
        vx = 0,
        vy = 0,
        sprite = love.graphics.newImage("sprites/Pallina_" .. i .. ".png")
    })
end

local offsetX = 16  -- spostamento a destra
local offsetY = 16  -- spostamento in basso

-- BUCHE
buche = {}
local holeR = 20   -- raggio buca

-- angoli superiori
table.insert(buche, {x = holeR,           y = holeR,           r = holeR}) -- alto sinistra
table.insert(buche, {x = tableWidth/2 + 11,    y = holeR,           r = holeR}) -- centro alto
table.insert(buche, {x = tableWidth - holeR + 2*offsetX, y = holeR,        r = holeR}) -- alto destra

-- angoli inferiori
table.insert(buche, {x = holeR,           y = tableHeight - holeR + 2*offsetY, r = holeR}) -- basso sinistra
table.insert(buche, {x = tableWidth/2 + 11,    y = tableHeight - holeR + 2*offsetY, r = holeR}) -- centro basso
table.insert(buche, {x = tableWidth - holeR + 2*offsetX, y = tableHeight - holeR + 2*offsetY, r = holeR}) -- basso destra