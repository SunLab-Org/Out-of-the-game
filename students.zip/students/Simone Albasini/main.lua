require "setup"
local power = 0
local scale = 2

local carica = false
local potenza = 0


local tavolo = {
    x = 16,
    y = 16,
    w = 1058,
    h = 424,
    sprite = love.graphics.newImage("Tavolo_biliardo.png")
}

local pallinaBianca = {
    x =850,
    y = tavolo.h/2,
    r = 15,
    vx = 0,
    vy = 0,
    hitrad = 50,
    sprite = love.graphics.newImage("sprites/Pallina_bianca.png")
}

local mazza = {
    x = 0,
    y = 0,
    rotation = 0,
    offsetX = 0,
    offsetY = 0,
    r = 40,
    sprite = love.graphics.newImage("sprites/Mazza.png")
}

local pallina = {
    x = 0,
    y = 0,
}




function collisione(a, b)
    local dx = b.x - a.x
    local dy = b.y - a.y
    local distSq = dx * dx + dy * dy
    local radii = a.r + b.r

    local coll = distSq <= radii * radii
    if not coll then
        return { coll = false }
    end

    local dist = math.sqrt(distSq)

    return {
        coll = true,
        dx = dx,
        dy = dy,
        dist = dist,
        overlap = radii - dist,
        angle = math.atan2(dy, dx)
    }
end


function love.load()
    love.window.setMode(1090, 600)
    mazza.offsetX = mazza.sprite:getWidth()
    mazza.offsetY = mazza.sprite:getHeight()
end

function love.update(dt)

    if carica then
        power = power + dt/10
        if power > 8 then power = 8 end
    end

    pallinaBianca.x = pallinaBianca.x + pallinaBianca.vx * dt
    pallinaBianca.y = pallinaBianca.y + pallinaBianca.vy * dt

    local mx, my = love.mouse.getPosition()
    mazza.x = mx
    mazza.y = my

    mazza.rotation = math.atan2(
        pallinaBianca.y - mazza.y,
        pallinaBianca.x - mazza.x
    )

    pallinaBianca.vx = pallinaBianca.vx * 0.98
    pallinaBianca.vy = pallinaBianca.vy * 0.98





    for _, pallina in ipairs(palline) do
        pallina.x = pallina.x + pallina.vx * dt
        pallina.y = pallina.y + pallina.vy * dt

        pallina.vx = pallina.vx * 0.98
        pallina.vy = pallina.vy * 0.98
    end

    for _, pallina in ipairs(palline) do
        local coll = collisione(pallinaBianca, pallina) 
        if coll.coll then
            bounce(pallinaBianca, pallina, coll)
        end

    end

    for _, pallina in ipairs(palline) do
        for _, pallina2 in ipairs(palline) do
            if not(pallina == pallina2) then
                local coll = collisione(pallina, pallina2)
                if coll.coll then
                    bounce(pallina, pallina2, coll)
                end
            end
        end
        if pallina.x - pallina.r < tavolo.x or pallina.x + pallina.r > tavolo.x + tavolo.w then
            pallina.vx = -pallina.vx
        end
        if pallina.y - pallina.r < tavolo.y or pallina.y + pallina.r > tavolo.y + tavolo.h then
            pallina.vy = -pallina.vy
        end

    end

    for i, pallina in ipairs(palline) do
        for _, buca in ipairs(buche) do
            if collisione(pallina, buca) then
                table.remove(palline, i)
            end
        end
    end

    if pallinaBianca.x - pallinaBianca.r < tavolo.x or pallinaBianca.x + pallinaBianca.r > tavolo.x + tavolo.w then
            pallinaBianca.vx = -pallinaBianca.vx
    end
    if pallinaBianca.y - pallinaBianca.r < tavolo.y or pallinaBianca.y + pallinaBianca.r > tavolo.y + tavolo.h then
        pallinaBianca.vy = -pallinaBianca.vy
    end



    if love.mouse.isDown("1") then
        power = power + 10*dt
    else 
        power = 0
    end
end


function love.draw()
    love.graphics.draw(tavolo.sprite, 0, 0, 0, scale * 4, scale * 4)
    love.graphics.rectangle("line", tavolo.x, tavolo.y, tavolo.w, tavolo.h)
   
    love.graphics.draw(
        mazza.sprite,
        mazza.x,
        mazza.y,
        mazza.rotation,
        scale + 1,
        scale + 1,
        mazza.offsetX,
        mazza.offsetY
    )

    for _, pallina in ipairs(palline) do
        love.graphics.circle("line", pallina.x, pallina.y, pallina.r)
        love.graphics.draw(
            pallina.sprite,
            pallina.x,
            pallina.y,
            0,
            scale,
            scale,
            pallina.r/2,
            pallina.r/2
        )
    end

    love.graphics.circle("line", pallinaBianca.x, pallinaBianca.y, pallinaBianca.r)

    love.graphics.draw(
        pallinaBianca.sprite,
        pallinaBianca.x,
        pallinaBianca.y,
        0,
        scale,
        scale,
        pallinaBianca.r/2,
        pallinaBianca.r/2
    )

    love.graphics.circle("line", pallinaBianca.x, pallinaBianca.y, pallinaBianca.hitrad)

    love.graphics.print("carica: "..power, 0, 500)

    -- Disegno buche
    love.graphics.setColor(0, 0, 0)   -- nero
    for _, h in ipairs(buche) do
        love.graphics.circle("fill", h.x, h.y, h.r)
    end
    love.graphics.setColor(1, 1, 1)   -- reset colore

end

function love.mousepressed(mx, my, button)
    if button ~= 1 then return end

    carica = true

end

function love.mousereleased(mx, my, button)
    if button ~= 1 then return end

    carica = false

    local cx = pallinaBianca.x
    local cy = pallinaBianca.y

    local dx = mx - cx
    local dy = my - cy
    local len = math.sqrt(dx * dx + dy * dy)

    if len == 0 then return end

    local nx = -dx / len
    local ny = -dy / len

    if len <= pallinaBianca.hitrad then
        pallinaBianca.vx = 200 * power * nx
        pallinaBianca.vy = 200 * power * ny
    end

    power = 0
end

function bounce(a,b, coll)
    -- Differenza delle posizioni
    local dx = b.x - a.x
    local dy = b.y - a.y
    local dist = math.sqrt(dx*dx + dy*dy)

    if dist == 0 then return end -- evita divisioni per zero

    -- Vettore normale (direzione dell'impatto)
    local nx = dx / dist
    local ny = dy / dist

    -- Vettore tangente (perpendicolare alla normale)
    local tx = -ny
    local ty = nx

    -- Proiezione delle velocità sulla normale e tangente
    local a_n = a.vx * nx + a.vy * ny
    local a_t = a.vx * tx + a.vy * ty

    local b_n = b.vx * nx + b.vy * ny
    local b_t = b.vx * tx + b.vy * ty

    -- Collisione elastica (masse uguali): scambio delle componenti normali
    local a_n_after = b_n
    local b_n_after = a_n

    -- Riconversione nelle coordinate X/Y
    a.vx = a_n_after * nx + a_t * tx
    a.vy = a_n_after * ny + a_t * ty

    b.vx = b_n_after * nx + b_t * tx
    b.vy = b_n_after * ny + b_t * ty

    -- Correzione dell'eventuale sovrapposizione (push-out)
    local overlap = (a.r + b.r) - dist
    if overlap > 0 then
        a.x = a.x - nx * (overlap / 2)
        a.y = a.y - ny * (overlap / 2)

        b.x = b.x + nx * (overlap / 2)
        b.y = b.y + ny * (overlap / 2)
    end
end

function love.keypressed(key)
    if key == "escape" then
        love.event.quit()
    end

end
