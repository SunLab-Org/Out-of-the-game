<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Pallina rimbalzante — #love</title>
<style>
  :root{
    --bg:#0f1724;
    --panel:#0b2540;
    --accent:#ff6b6b;
    --text:#e6eef6;
  }
  html,body{height:100%;margin:0;font-family:system-ui,Arial,sans-serif;background:linear-gradient(180deg,var(--bg),#081023);color:var(--text)}
  .wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;padding:24px;box-sizing:border-box}
  /* contenitore #love */
  #love{
    width:min(880px,95vw);
    height:min(520px,55vh);
    background:linear-gradient(180deg,#07203a 0%, #0b2a3e 100%);
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.6), inset 0 2px 8px rgba(255,255,255,0.02);
    padding:12px;
    box-sizing:border-box;
    display:flex;
    align-items:center;
    justify-content:center;
    position:relative;
    overflow:hidden;
  }
  canvas{width:100%;height:100%;display:block;border-radius:8px}
  .controls{
    display:flex;gap:10px;align-items:center;flex-wrap:wrap;
    background:rgba(255,255,255,0.03);padding:10px;border-radius:8px;
    box-shadow:0 6px 18px rgba(2,6,23,0.6);
  }
  .btn{
    background:var(--accent);color:#fff;border:none;padding:8px 12px;border-radius:8px;cursor:pointer;font-weight:600;
  }
  .small{padding:6px 8px;font-size:14px}
  label{font-size:14px;color:#cfe8ff}
  input[type=range]{accent-color:var(--accent)}
  footer{font-size:13px;color:#9fbcd9;margin-top:6px}
  @media (max-width:480px){
    #love{height:48vh}
    .controls{font-size:14px}
  }
</style>
</head>
<body>
<div class="wrap">
  <div id="love" aria-label="Area di gioco con pallina rimbalzante">
    <canvas id="game"></canvas>
  </div>

  <div class="controls" role="region" aria-label="Controlli">
    <button id="playPause" class="btn small">Pausa</button>
    <label>Velocità <input id="speed" type="range" min="0.25" max="3" step="0.05" value="1"></label>
    <label>Raggio <input id="radius" type="range" min="6" max="40" step="1" value="14"></label>
    <button id="reset" class="small">Reset posizione</button>
  </div>

  <footer>Fare clic sulla tela per cambiare direzione. Ridimensiona la finestra per adattare l'area.</footer>
</div>

<script>
(function(){
  const canvas = document.getElementById('game');
  const container = document.getElementById('love');
  const ctx = canvas.getContext('2d', {alpha:true});

  // impostazioni iniziali
  let DPR = Math.max(1, window.devicePixelRatio || 1);
  let speedFactor = +document.getElementById('speed').value;
  let radius = +document.getElementById('radius').value;

  // pallina
  const ball = {
    x: 100,
    y: 100,
    vx: 180, // px/s
    vy: 130, // px/s
    r: radius,
    color: '#ffd166'
  };

  let last = null;
  let running = true;

  function resizeCanvas(){
    // dimensione reale in pixel per nitidezza
    const rect = container.getBoundingClientRect();
    DPR = Math.max(1, window.devicePixelRatio || 1);
    canvas.width = Math.round(rect.width * DPR);
    canvas.height = Math.round(rect.height * DPR);
    canvas.style.width = rect.width + 'px';
    canvas.style.height = rect.height + 'px';
    ctx.setTransform(DPR,0,0,DPR,0,0);
    // assicurati che la pallina sia entro i nuovi confini
    ball.x = Math.max(ball.r, Math.min(ball.x, rect.width - ball.r));
    ball.y = Math.max(ball.r, Math.min(ball.y, rect.height - ball.r));
  }

  // disegna background e pallina
  function draw(){
    const rect = container.getBoundingClientRect();
    ctx.clearRect(0,0,rect.width,rect.height);

    // bordo visivo
    ctx.save();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    roundRect(ctx,1,1,rect.width-2,rect.height-2,8);
    ctx.stroke();
    ctx.restore();

    // disegna pallina con ombra
    ctx.beginPath();
    ctx.fillStyle = ball.color;
    ctx.shadowColor = 'rgba(0,0,0,0.45)';
    ctx.shadowBlur = Math.max(6, ball.r/2);
    ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI*2);
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  function roundRect(ctx,x,y,w,h,r){
    ctx.beginPath();
    ctx.moveTo(x+r,y);
    ctx.arcTo(x+w,y,x+w,y+h,r);
    ctx.arcTo(x+w,y+h,x,y+h,r);
    ctx.arcTo(x,y+h,x,y,r);
    ctx.arcTo(x,y,x+w,y,r);
    ctx.closePath();
  }

  function step(ts){
    if(!last) last = ts;
    const dt = Math.min(0.05, (ts - last)/1000); // dt in s (cap a 50ms)
    last = ts;
    if(running){
      update(dt * speedFactor);
      draw();
    }
    requestAnimationFrame(step);
  }

  function update(dt){
    const rect = container.getBoundingClientRect();
    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;

    // collisione con i bordi - riflessione e lettura posizione
    if(ball.x - ball.r <= 0){
      ball.x = ball.r;
      ball.vx = Math.abs(ball.vx); bounce('x');
    } else if(ball.x + ball.r >= rect.width){
      ball.x = rect.width - ball.r;
      ball.vx = -Math.abs(ball.vx); bounce('x');
    }
    if(ball.y - ball.r <= 0){
      ball.y = ball.r;
      ball.vy = Math.abs(ball.vy); bounce('y');
    } else if(ball.y + ball.r >= rect.height){
      ball.y = rect.height - ball.r;
      ball.vy = -Math.abs(ball.vy); bounce('y');
    }
  }

  function bounce(axis){
    // cambia colore al rimbalzo e attenua velocità leggermente
    ball.color = randomColor();
    ball.vx *= 0.995;
    ball.vy *= 0.995;
  }

  function randomColor(){
    // palette vivace
    const palette = ['#ffd166','#06d6a0','#118ab2','#ef476f','#9b5de5','#f9c74f'];
    return palette[Math.floor(Math.random()*palette.length)];
  }

  // controlli UI
  document.getElementById('playPause').addEventListener('click', ()=>{
    running = !running;
    document.getElementById('playPause').textContent = running ? 'Pausa' : 'Avvia';
  });

  document.getElementById('speed').addEventListener('input', (e)=>{
    speedFactor = +e.target.value;
  });

  document.getElementById('radius').addEventListener('input', (e)=>{
    ball.r = +e.target.value;
    radius = ball.r;
    // assicurati entro bordi
    resizeCanvas();
    draw();
  });

  document.getElementById('reset').addEventListener('click', ()=>{
    const rect = container.getBoundingClientRect();
    ball.x = rect.width/2;
    ball.y = rect.height/2;
    ball.vx = 180;
    ball.vy = 130;
    ball.color = '#ffd166';
    draw();
  });

  // clic sulla tela cambia direzione
  canvas.addEventListener('click', (ev)=>{
    // inverti velocità e sposta verso il punto cliccato
    const rect = canvas.getBoundingClientRect();
    const cx = (ev.clientX - rect.left);
    const cy = (ev.clientY - rect.top);
    // orienta la velocità verso punto (con mantenimento di modulo)
    const dx = cx - ball.x;
    const dy = cy - ball.y;
    const mag = Math.hypot(dx,dy) || 1;
    const speed = Math.hypot(ball.vx, ball.vy);
    ball.vx = (dx/mag) * speed;
    ball.vy = (dy/mag) * speed;
  });

  // gestione resize
  window.addEventListener('resize', ()=>{
    resizeCanvas();
    draw();
  });

  // inizializza posizione centrale e avvia animazione
  function init(){
    resizeCanvas();
    const rect = container.getBoundingClientRect();
    ball.x = rect.width/2;
    ball.y = rect.height/2;
    ball.r = radius;
    draw();
    requestAnimationFrame(step);
  }

  init();

})();
</script>
</body>
</html>
